const mongoose = require('mongoose');
require('../models/travlr');

const Trip = mongoose.model('trips');

const MAX_PAGE_SIZE = 50;
const DEFAULT_PAGE_SIZE = 10;

const ALLOWED_SORT_FIELDS = [
    'name',
    'code',
    'resort',
    'start',
    'perPerson'
];

// Validate incoming trip data before it is sent to the database.
const validateTripData = (tripData) => {
    const requiredFields = [
        'code',
        'name',
        'length',
        'start',
        'resort',
        'perPerson',
        'image',
        'description'
    ];

    const missingFields = requiredFields.filter((field) => {
        const value = tripData[field];

        return (
            value === undefined ||
            value === null ||
            (typeof value === 'string' && value.trim() === '')
        );
    });

    if (missingFields.length > 0) {
        return {
            valid: false,
            message: `Missing required fields: ${missingFields.join(', ')}`
        };
    }

    const price = Number(tripData.perPerson);

    if (!Number.isFinite(price) || price < 0) {
        return {
            valid: false,
            message: 'Price per person must be a valid non-negative number.'
        };
    }

    const startDate = new Date(tripData.start);

    if (Number.isNaN(startDate.getTime())) {
        return {
            valid: false,
            message: 'Start date must be a valid date.'
        };
    }

    return {
        valid: true,
        price,
        startDate
    };
};

// Escape special regular-expression characters supplied by a user.
const escapeRegExp = (value) => {
    return value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
};

// GET: /api/trips
// Supports targeted searching, filtering, sorting, and pagination.
const tripsList = async (req, res) => {
    try {
        const {
            search,
            resort,
            sortBy = 'name',
            order = 'asc'
        } = req.query;

        const requestedPage = Number.parseInt(req.query.page, 10);
        const requestedLimit = Number.parseInt(req.query.limit, 10);

        const page =
            Number.isInteger(requestedPage) && requestedPage > 0
                ? requestedPage
                : 1;

        const limit =
            Number.isInteger(requestedLimit) && requestedLimit > 0
                ? Math.min(requestedLimit, MAX_PAGE_SIZE)
                : DEFAULT_PAGE_SIZE;

        const query = {};

        if (search && typeof search === 'string' && search.trim()) {
            const safeSearch = escapeRegExp(search.trim());

            query.$or = [
                {
                    name: {
                        $regex: safeSearch,
                        $options: 'i'
                    }
                },
                {
                    code: {
                        $regex: safeSearch,
                        $options: 'i'
                    }
                },
                {
                    resort: {
                        $regex: safeSearch,
                        $options: 'i'
                    }
                }
            ];
        }

        if (resort && typeof resort === 'string' && resort.trim()) {
            query.resort = {
                $regex: `^${escapeRegExp(resort.trim())}$`,
                $options: 'i'
            };
        }

        const selectedSortField = ALLOWED_SORT_FIELDS.includes(sortBy)
            ? sortBy
            : 'name';

        const sortDirection =
            typeof order === 'string' &&
                order.toLowerCase() === 'desc'
                ? -1
                : 1;

        const skip = (page - 1) * limit;

        const [totalTrips, trips] = await Promise.all([
            Trip.countDocuments(query).exec(),
            Trip.find(query)
                .sort({ [selectedSortField]: sortDirection })
                .skip(skip)
                .limit(limit)
                .exec()
        ]);

        const totalPages =
            totalTrips === 0
                ? 0
                : Math.ceil(totalTrips / limit);

        return res.status(200).json({
            trips,
            pagination: {
                currentPage: page,
                pageSize: limit,
                totalTrips,
                totalPages,
                hasPreviousPage: page > 1 && totalPages > 0,
                hasNextPage: page < totalPages
            },
            criteria: {
                search: search || '',
                resort: resort || '',
                sortBy: selectedSortField,
                order: sortDirection === 1 ? 'asc' : 'desc'
            }
        });
    } catch (err) {
        console.error('Error retrieving trips:', err.message);

        return res.status(500).json({
            message: 'Unable to retrieve trips.'
        });
    }
};

// GET: /api/trips/:tripCode
const tripsFindByCode = async (req, res) => {
    try {
        const trip = await Trip
            .findOne({ code: req.params.tripCode })
            .exec();

        if (!trip) {
            return res.status(404).json({
                message: 'Trip not found.'
            });
        }

        return res.status(200).json(trip);
    } catch (err) {
        console.error('Error retrieving trip:', err.message);

        return res.status(500).json({
            message: 'Unable to retrieve the requested trip.'
        });
    }
};

// POST: /api/trips
const tripsAddTrip = async (req, res) => {
    const validation = validateTripData(req.body);

    if (!validation.valid) {
        return res.status(400).json({
            message: validation.message
        });
    }

    try {
        const newTrip = await Trip.create({
            code: req.body.code.trim(),
            name: req.body.name.trim(),
            length: req.body.length.trim(),
            start: validation.startDate,
            resort: req.body.resort.trim(),
            perPerson: validation.price,
            image: req.body.image.trim(),
            description: req.body.description.trim()
        });

        return res.status(201).json(newTrip);
    } catch (err) {
        console.error('Error creating trip:', err.message);

        if (err.code === 11000) {
            return res.status(409).json({
                message: 'A trip with that code already exists.'
            });
        }

        return res.status(400).json({
            message: 'Unable to create trip. Please verify the submitted data.'
        });
    }
};

// PUT: /api/trips/:tripCode
const tripsUpdateTrip = async (req, res) => {
    const validation = validateTripData(req.body);

    if (!validation.valid) {
        return res.status(400).json({
            message: validation.message
        });
    }

    try {
        const updatedTrip = await Trip
            .findOneAndUpdate(
                { code: req.params.tripCode },
                {
                    code: req.body.code.trim(),
                    name: req.body.name.trim(),
                    length: req.body.length.trim(),
                    start: validation.startDate,
                    resort: req.body.resort.trim(),
                    perPerson: validation.price,
                    image: req.body.image.trim(),
                    description: req.body.description.trim()
                },
                {
                    new: true,
                    runValidators: true
                }
            )
            .exec();

        if (!updatedTrip) {
            return res.status(404).json({
                message: 'Trip not found.'
            });
        }

        return res.status(200).json(updatedTrip);
    } catch (err) {
        console.error('Error updating trip:', err.message);

        if (err.code === 11000) {
            return res.status(409).json({
                message: 'A trip with that code already exists.'
            });
        }

        return res.status(400).json({
            message: 'Unable to update trip. Please verify the submitted data.'
        });
    }
};

// DELETE: /api/trips/:tripCode
const tripsDeleteTrip = async (req, res) => {
    try {
        const deletedTrip = await Trip
            .findOneAndDelete({
                code: req.params.tripCode
            })
            .exec();

        if (!deletedTrip) {
            return res.status(404).json({
                message: 'Trip not found.'
            });
        }

        return res.status(204).send();
    } catch (err) {
        console.error('Error deleting trip:', err.message);

        return res.status(500).json({
            message: 'Unable to delete trip.'
        });
    }
};

module.exports = {
    tripsList,
    tripsFindByCode,
    tripsAddTrip,
    tripsUpdateTrip,
    tripsDeleteTrip
};