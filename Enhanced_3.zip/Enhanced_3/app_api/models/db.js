const mongoose = require('mongoose');
const host = process.env.DB_HOST || '127.0.0.1';
const dbURI = `mongodb://${host}/travlr`;

const readLine = require('readline');

// Import schemas before connecting so indexes are registered.
require('./travlr');

// Build the connection string and synchronize database indexes.
const connect = async () => {
    try {
        await mongoose.connect(dbURI);

        console.log(`Mongoose connected to ${dbURI}`);

        await mongoose.model('trips').syncIndexes();

        console.log('Trip database indexes synchronized');
    } catch (err) {
        console.error('Mongoose connection/index error:', err);
    }
};

// Monitor connection events.
mongoose.connection.on('error', err => {
    console.log('Mongoose connection error:', err);
});

mongoose.connection.on('disconnected', () => {
    console.log('Mongoose disconnected');
});

// Windows-specific listener.
if (process.platform === 'win32') {
    const rl = readLine.createInterface({
        input: process.stdin,
        output: process.stdout
    });

    rl.on('SIGINT', () => {
        process.emit('SIGINT');
    });
}

// Graceful shutdown.
const gracefulShutdown = async (msg) => {
    await mongoose.connection.close();
    console.log(`Mongoose disconnected through ${msg}`);
};

// Event listeners.
process.once('SIGUSR2', async () => {
    await gracefulShutdown('nodemon restart');
    process.kill(process.pid, 'SIGUSR2');
});

process.on('SIGINT', async () => {
    await gracefulShutdown('app termination');
    process.exit(0);
});

process.on('SIGTERM', async () => {
    await gracefulShutdown('app shutdown');
    process.exit(0);
});

// Make initial connection.
connect();

module.exports = mongoose;