const mongoose = require('mongoose');

// Define the trip schema with database-level validation.
const tripSchema = new mongoose.Schema({
    code: {
        type: String,
        required: [true, 'Trip code is required.'],
        unique: true,
        trim: true,
        minlength: 2,
        maxlength: 20
    },
    name: {
        type: String,
        required: [true, 'Trip name is required.'],
        trim: true,
        minlength: 2,
        maxlength: 100,
        index: true
    },
    length: {
        type: String,
        required: [true, 'Trip length is required.'],
        trim: true,
        maxlength: 50
    },
    start: {
        type: Date,
        required: [true, 'Start date is required.'],
        index: true
    },
    resort: {
        type: String,
        required: [true, 'Resort is required.'],
        trim: true,
        minlength: 2,
        maxlength: 100,
        index: true
    },
    perPerson: {
        type: Number,
        required: [true, 'Price per person is required.'],
        min: [0, 'Price per person cannot be negative.']
    },
    image: {
        type: String,
        required: [true, 'Image is required.'],
        trim: true,
        maxlength: 255
    },
    description: {
        type: String,
        required: [true, 'Description is required.'],
        trim: true,
        minlength: 10,
        maxlength: 1000
    }
}, {
    timestamps: true
});

// Compound index supports common resort/date queries.
tripSchema.index({
    resort: 1,
    start: 1
});

const Trip = mongoose.model('trips', tripSchema);

module.exports = Trip;