import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import {
  FormBuilder,
  FormGroup,
  ReactiveFormsModule,
  Validators
} from '@angular/forms';
import { Router } from '@angular/router';

import { TripData } from '../services/trip-data';
import { Trip } from '../models/trip';

@Component({
  selector: 'app-add-trip',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './add-trip.html',
  styleUrl: './add-trip.css',
})
export class AddTrip {
  addForm: FormGroup;
  submitted = false;
  message = '';

  constructor(
    private formBuilder: FormBuilder,
    private router: Router,
    private tripDataService: TripData
  ) {
    // Client-side validation provides immediate feedback before data
    // is submitted to the API.
    this.addForm = this.formBuilder.group({
      code: [
        '',
        [
          Validators.required,
          Validators.minLength(2),
          Validators.maxLength(20)
        ]
      ],
      name: [
        '',
        [
          Validators.required,
          Validators.minLength(2),
          Validators.maxLength(100)
        ]
      ],
      length: [
        '',
        [
          Validators.required,
          Validators.maxLength(50)
        ]
      ],
      start: [
        '',
        Validators.required
      ],
      resort: [
        '',
        [
          Validators.required,
          Validators.minLength(2),
          Validators.maxLength(100)
        ]
      ],
      perPerson: [
        null,
        [
          Validators.required,
          Validators.min(0)
        ]
      ],
      image: [
        '',
        [
          Validators.required,
          Validators.maxLength(255)
        ]
      ],
      description: [
        '',
        [
          Validators.required,
          Validators.minLength(10),
          Validators.maxLength(1000)
        ]
      ]
    });
  }

  get formControls() {
    return this.addForm.controls;
  }

  onSubmit(): void {
    this.submitted = true;
    this.message = '';

    if (this.addForm.invalid) {
      this.message = 'Please correct the highlighted fields before submitting.';
      return;
    }

    const formValue = this.addForm.value;

    const newTrip: Trip = {
      ...formValue,
      code: formValue.code.trim(),
      name: formValue.name.trim(),
      length: formValue.length.trim(),
      resort: formValue.resort.trim(),
      perPerson: Number(formValue.perPerson),
      image: formValue.image.trim(),
      description: formValue.description.trim()
    };

    this.tripDataService.addTrip(newTrip).subscribe({
      next: () => {
        this.message = 'Trip added successfully.';
        this.router.navigate(['/']);
      },
      error: (error: unknown) => {
        console.error('Error adding trip:', error);
        this.message =
          'Unable to add the trip. Please verify the trip information and try again.';
      }
    });
  }
}
