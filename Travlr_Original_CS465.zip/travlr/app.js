const express = require('express');
const path = require('path');
const hbs = require('hbs');
const cors = require('cors');
require('dotenv').config();
const passport = require('passport');
require('./app_api/config/passport');

require('./app_api/models/db');

const indexRouter = require('./app_server/routes/index');
const apiRouter = require('./app_api/routes/index');
const tripsController = require('./app_api/controllers/trips');

const app = express();
const PORT = 3000;

app.use(
    cors({
        origin: 'http://localhost:4200',
        methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
        allowedHeaders: ['Content-Type', 'Authorization']
    })
);

app.use(express.json());
app.use(express.urlencoded({ extended: false }));

app.set('view engine', 'hbs');
app.set('views', path.join(__dirname, 'app_server', 'views'));

hbs.registerPartials(
    path.join(__dirname, 'app_server', 'views', 'partials')
);

app.use(express.static(path.join(__dirname, 'public')));
app.use(passport.initialize());

// Routes
app.post('/api/trips', tripsController.tripsAddTrip);
app.use('/api', apiRouter);
app.use('/', indexRouter);

app.listen(PORT, () => {
    console.log(`Travlr Getaways is running at http://localhost:${PORT}`);
});