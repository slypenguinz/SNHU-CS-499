import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';

import { Trip } from '../models/trip';
import { User } from '../models/user';
import { AuthResponse } from '../models/auth-response';

// Defines the structure returned by the enhanced trips API.
export interface TripResponse {
  trips: Trip[];
  pagination: {
    currentPage: number;
    pageSize: number;
    totalTrips: number;
    totalPages: number;
    hasPreviousPage: boolean;
    hasNextPage: boolean;
  };
  criteria: {
    search: string;
    resort: string;
    sortBy: string;
    order: string;
  };
}

// Optional parameters used for searching, sorting, and pagination.
export interface TripQuery {
  search?: string;
  resort?: string;
  sortBy?: string;
  order?: 'asc' | 'desc';
  page?: number;
  limit?: number;
}

@Injectable({
  providedIn: 'root',
})
export class TripData {

  private baseUrl = '/api';

  constructor(private http: HttpClient) { }

  public getTrips(query: TripQuery = {}): Observable<TripResponse> {
    let params = new HttpParams();

    if (query.search) {
      params = params.set('search', query.search);
    }

    if (query.resort) {
      params = params.set('resort', query.resort);
    }

    if (query.sortBy) {
      params = params.set('sortBy', query.sortBy);
    }

    if (query.order) {
      params = params.set('order', query.order);
    }

    if (query.page !== undefined) {
      params = params.set('page', query.page.toString());
    }

    if (query.limit !== undefined) {
      params = params.set('limit', query.limit.toString());
    }

    return this.http.get<TripResponse>(
      `${this.baseUrl}/trips`,
      { params }
    );
  }

  public getTrip(tripCode: string): Observable<Trip> {
    return this.http.get<Trip>(
      `${this.baseUrl}/trips/${tripCode}`
    );
  }

  public addTrip(formData: Trip): Observable<Trip> {
    return this.http.post<Trip>(
      `${this.baseUrl}/trips`,
      formData
    );
  }

  public updateTrip(formData: Trip): Observable<Trip> {
    return this.http.put<Trip>(
      `${this.baseUrl}/trips/${formData.code}`,
      formData
    );
  }

  public deleteTrip(tripCode: string): Observable<any> {
    return this.http.delete(
      `${this.baseUrl}/trips/${tripCode}`
    );
  }

  public login(
    user: User,
    passwd: string
  ): Observable<AuthResponse> {

    return this.handleAuthAPICall(
      'login',
      user,
      passwd
    );
  }

  public register(
    user: User,
    passwd: string
  ): Observable<AuthResponse> {

    return this.handleAuthAPICall(
      'register',
      user,
      passwd
    );
  }

  private handleAuthAPICall(
    endpoint: string,
    user: User,
    passwd: string
  ): Observable<AuthResponse> {

    const formData = {
      name: user.name,
      email: user.email,
      password: passwd
    };

    return this.http.post<AuthResponse>(
      `${this.baseUrl}/${endpoint}`,
      formData
    );
  }
}
