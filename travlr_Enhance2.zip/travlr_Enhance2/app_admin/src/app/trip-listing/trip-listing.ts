import {
  ChangeDetectorRef,
  Component,
  OnInit
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';

import { TripCard } from '../trip-card/trip-card';
import {
  TripData,
  TripResponse
} from '../services/trip-data';
import { Trip } from '../models/trip';
import { Authentication } from '../services/authentication';

@Component({
  selector: 'app-trip-listing',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    RouterLink,
    TripCard
  ],
  templateUrl: './trip-listing.html',
  styleUrl: './trip-listing.css',
})
export class TripListing implements OnInit {

  trips: Trip[] = [];
  message = '';

  // Search and sorting controls.
  searchTerm = '';
  sortBy = 'name';
  sortOrder: 'asc' | 'desc' = 'asc';

  // Pagination state.
  currentPage = 1;
  pageSize = 2;
  totalTrips = 0;
  totalPages = 0;
  hasPreviousPage = false;
  hasNextPage = false;

  constructor(
    private tripDataService: TripData,
    private authenticationService: Authentication,
    private changeDetectorRef: ChangeDetectorRef
  ) { }

  ngOnInit(): void {
    this.getTrips();
  }

  public isLoggedIn(): boolean {
    return this.authenticationService.isLoggedIn();
  }

  private getTrips(): void {
    this.tripDataService.getTrips({
      search: this.searchTerm.trim(),
      sortBy: this.sortBy,
      order: this.sortOrder,
      page: this.currentPage,
      limit: this.pageSize
    }).subscribe({
      next: (response: TripResponse) => {
        this.trips = response.trips;

        this.currentPage = response.pagination.currentPage;
        this.pageSize = response.pagination.pageSize;
        this.totalTrips = response.pagination.totalTrips;
        this.totalPages = response.pagination.totalPages;
        this.hasPreviousPage = response.pagination.hasPreviousPage;
        this.hasNextPage = response.pagination.hasNextPage;

        if (this.totalTrips > 0) {
          this.message =
            `${this.totalTrips} trip(s) found. ` +
            `Showing page ${this.currentPage} of ${this.totalPages}.`;
        } else {
          this.message = 'No trips matched the current search.';
        }

        this.changeDetectorRef.detectChanges();
      },
      error: (error: unknown) => {
        console.error('Error retrieving trips:', error);
        this.message = 'Unable to retrieve trips from the database.';
        this.changeDetectorRef.detectChanges();
      }
    });
  }

  public searchTrips(): void {
    // A new search always begins on the first page.
    this.currentPage = 1;
    this.getTrips();
  }

  public clearSearch(): void {
    this.searchTerm = '';
    this.currentPage = 1;
    this.getTrips();
  }

  public changeSort(): void {
    this.currentPage = 1;
    this.getTrips();
  }

  public previousPage(): void {
    if (!this.hasPreviousPage) {
      return;
    }

    this.currentPage--;
    this.getTrips();
  }

  public nextPage(): void {
    if (!this.hasNextPage) {
      return;
    }

    this.currentPage++;
    this.getTrips();
  }

  public deleteTrip(tripCode: string): void {
    const confirmed = window.confirm(
      `Are you sure you want to delete trip ${tripCode}?`
    );

    if (!confirmed) {
      return;
    }

    this.tripDataService.deleteTrip(tripCode).subscribe({
      next: () => {
        // Reload the current query after deletion so the page,
        // count, and pagination metadata remain accurate.
        this.getTrips();
      },
      error: (error: unknown) => {
        console.error('Error deleting trip:', error);
        this.message = 'Unable to delete the trip.';
        this.changeDetectorRef.detectChanges();
      }
    });
  }
}
