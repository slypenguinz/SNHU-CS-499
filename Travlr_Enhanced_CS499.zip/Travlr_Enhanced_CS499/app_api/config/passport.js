const passport = require('passport');
const LocalStrategy = require('passport-local').Strategy;
const User = require('../models/user');

// Configure Passport to authenticate users with their email and password.
passport.use(
    new LocalStrategy(
        {
            usernameField: 'email'
        },
        async (email, password, done) => {
            try {
                // Normalize the email so authentication uses the same
                // format that is stored during user registration.
                const normalizedEmail = email.trim().toLowerCase();

                const user = await User.findOne({
                    email: normalizedEmail
                }).exec();

                // Use the same message for an unknown email or incorrect
                // password so authentication does not reveal account details.
                if (!user) {
                    return done(null, false, {
                        message: 'Invalid email or password.'
                    });
                }

                // Compare the submitted password against the stored hash.
                if (!user.validPassword(password)) {
                    return done(null, false, {
                        message: 'Invalid email or password.'
                    });
                }

                // Authentication succeeded.
                return done(null, user);
            } catch (err) {
                // Pass unexpected database or application errors back
                // to Passport for centralized error handling.
                console.error('Passport authentication error:', err.message);
                return done(err);
            }
        }
    )
);