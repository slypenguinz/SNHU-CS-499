const User = require('../models/user');
const passport = require('passport');

// Basic email format validation for registration and login requests.
const isValidEmail = (email) => {
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailPattern.test(email);
};

// Validate password requirements before creating a new user.
const isValidPassword = (password) => {
    return (
        typeof password === 'string' &&
        password.length >= 8
    );
};

// POST: /api/register
// Register a new user after validating the submitted account information.
const register = async (req, res) => {
    const { name, email, password } = req.body;

    // All registration fields are required.
    if (!name || !email || !password) {
        return res.status(400).json({
            message: 'Name, email, and password are required.'
        });
    }

    // Prevent empty values containing only whitespace.
    if (
        typeof name !== 'string' ||
        typeof email !== 'string' ||
        typeof password !== 'string' ||
        name.trim() === '' ||
        email.trim() === ''
    ) {
        return res.status(400).json({
            message: 'Registration information is invalid.'
        });
    }

    const normalizedEmail = email.trim().toLowerCase();

    // Validate the email before attempting to create the account.
    if (!isValidEmail(normalizedEmail)) {
        return res.status(400).json({
            message: 'Please provide a valid email address.'
        });
    }

    // Require a minimum password length to improve account security.
    if (!isValidPassword(password)) {
        return res.status(400).json({
            message: 'Password must contain at least 8 characters.'
        });
    }

    try {
        // Check for an existing account before attempting registration.
        const existingUser = await User.findOne({
            email: normalizedEmail
        }).exec();

        if (existingUser) {
            return res.status(409).json({
                message: 'An account with this email already exists.'
            });
        }

        const user = new User({
            name: name.trim(),
            email: normalizedEmail
        });

        // Password hashing is handled by the User model.
        user.setPassword(password);

        await user.save();

        // Generate a JWT after successful account creation.
        const token = user.generateJWT();

        return res.status(201).json({
            token
        });
    } catch (err) {
        // Keep detailed database errors on the server instead of
        // exposing internal application information to the client.
        console.error('Registration error:', err.message);

        return res.status(500).json({
            message: 'Unable to create the account.'
        });
    }
};

// POST: /api/login
// Authenticate an existing user and return a JWT after successful login.
const login = (req, res) => {
    const { email, password } = req.body;

    // Both credentials are required before authentication is attempted.
    if (!email || !password) {
        return res.status(400).json({
            message: 'Email and password are required.'
        });
    }

    if (
        typeof email !== 'string' ||
        typeof password !== 'string' ||
        email.trim() === ''
    ) {
        return res.status(400).json({
            message: 'Login information is invalid.'
        });
    }

    const normalizedEmail = email.trim().toLowerCase();

    if (!isValidEmail(normalizedEmail)) {
        return res.status(400).json({
            message: 'Please provide a valid email address.'
        });
    }

    // Store the normalized email so Passport authenticates
    // against the same format used during registration.
    req.body.email = normalizedEmail;

    // Delegate credential verification to the Passport local strategy.
    passport.authenticate('local', (err, user) => {
        if (err) {
            console.error('Authentication error:', err.message);

            return res.status(500).json({
                message: 'Unable to process the login request.'
            });
        }

        if (!user) {
            // Use a generic response so the API does not reveal
            // whether a particular email address exists.
            return res.status(401).json({
                message: 'Invalid email or password.'
            });
        }

        try {
            // Authentication succeeded, so create a time-limited JWT.
            const token = user.generateJWT();

            return res.status(200).json({
                token
            });
        } catch (err) {
            console.error('Token generation error:', err.message);

            return res.status(500).json({
                message: 'Unable to complete authentication.'
            });
        }
    })(req, res);
};

module.exports = {
    register,
    login
};