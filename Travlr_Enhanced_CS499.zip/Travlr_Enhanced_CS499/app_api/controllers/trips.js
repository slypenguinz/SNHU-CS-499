const mongoose = require('mongoose');
require('../models/travlr');

const Trip = mongoose.model('trips');

// Validate incoming trip data before it is sent to the database.
// Server-side validation protects the API even if client-side
// validation is bypassed or the API is called directly.
const validateTripData = (tripData) => {
    const requiredFields = [
        'code',
        'name',
        'length',
        'start',
        'resort',
        'perPerson',
        'image',
        'description'
    ];

    const missingFields = requiredFields.filter((field) => {
        const value = tripData[field];

        return (
            value === undefined ||
            value === null ||
            (typeof value === 'string' && value.trim() === '')
        );
    });

    if (missingFields.length > 0) {
        return {
            valid: false,
            message: `Missing required fields: ${missingFields.join(', ')}`
        };
    }

    return {
        valid: true
    };
};

// GET: /api/trips
// Retrieve all available trip records.
const tripsList = async (req, res) => {
    try {
        const trips = await Trip.find({}).exec();

        if (!trips || trips.length === 0) {
            return res.status(404).json({
                message: 'No trips found.'
            });
        }

        return res.status(200).json(trips);
    } catch (err) {
        // Log detailed errors on the server without exposing
        // internal database information to the client.
        console.error('Error retrieving trips:', err.message);

        return res.status(500).json({
            message: 'Unable to retrieve trips.'
        });
    }
};

// GET: /api/trips/:tripCode
// Retrieve one trip using its unique trip code.
const tripsFindByCode = async (req, res) => {
    try {
        const trip = await Trip
            .findOne({ code: req.params.tripCode })
            .exec();

        if (!trip) {
            return res.status(404).json({
                message: 'Trip not found.'
            });
        }

        return res.status(200).json(trip);
    } catch (err) {
        console.error('Error retrieving trip:', err.message);

        return res.status(500).json({
            message: 'Unable to retrieve the requested trip.'
        });
    }
};

// POST: /api/trips
// Create a new trip after validating all required request data.
const tripsAddTrip = async (req, res) => {
    const validation = validateTripData(req.body);

    if (!validation.valid) {
        return res.status(400).json({
            message: validation.message
        });
    }

    try {
        const newTrip = await Trip.create({
            code: req.body.code.trim(),
            name: req.body.name.trim(),
            length: req.body.length.trim(),
            start: req.body.start,
            resort: req.body.resort.trim(),
            perPerson: req.body.perPerson.trim(),
            image: req.body.image.trim(),
            description: req.body.description.trim()
        });

        return res.status(201).json(newTrip);
    } catch (err) {
        console.error('Error creating trip:', err.message);

        return res.status(400).json({
            message: 'Unable to create trip. Please verify the submitted data.'
        });
    }
};

// PUT: /api/trips/:tripCode
// Update an existing trip after validating the submitted data.
const tripsUpdateTrip = async (req, res) => {
    const validation = validateTripData(req.body);

    if (!validation.valid) {
        return res.status(400).json({
            message: validation.message
        });
    }

    try {
        const updatedTrip = await Trip
            .findOneAndUpdate(
                { code: req.params.tripCode },
                {
                    code: req.body.code.trim(),
                    name: req.body.name.trim(),
                    length: req.body.length.trim(),
                    start: req.body.start,
                    resort: req.body.resort.trim(),
                    perPerson: req.body.perPerson.trim(),
                    image: req.body.image.trim(),
                    description: req.body.description.trim()
                },
                {
                    new: true,
                    runValidators: true
                }
            )
            .exec();

        if (!updatedTrip) {
            return res.status(404).json({
                message: 'Trip not found.'
            });
        }

        return res.status(200).json(updatedTrip);
    } catch (err) {
        console.error('Error updating trip:', err.message);

        return res.status(400).json({
            message: 'Unable to update trip. Please verify the submitted data.'
        });
    }
};

// DELETE: /api/trips/:tripCode
// Delete a trip using its trip code.
const tripsDeleteTrip = async (req, res) => {
    try {
        const deletedTrip = await Trip
            .findOneAndDelete({
                code: req.params.tripCode
            })
            .exec();

        if (!deletedTrip) {
            return res.status(404).json({
                message: 'Trip not found.'
            });
        }

        return res.status(204).send();
    } catch (err) {
        console.error('Error deleting trip:', err.message);

        return res.status(500).json({
            message: 'Unable to delete trip.'
        });
    }
};

module.exports = {
    tripsList,
    tripsFindByCode,
    tripsAddTrip,
    tripsUpdateTrip,
    tripsDeleteTrip
};