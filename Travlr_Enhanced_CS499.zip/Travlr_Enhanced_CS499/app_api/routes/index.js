const express = require('express');
const router = express.Router();
const jwt = require('jsonwebtoken');

const tripsController = require('../controllers/trips');
const authController = require('../controllers/authentication');


// Authenticate JSON Web Tokens before allowing access to protected routes.
function authenticateJWT(req, res, next) {
    const authHeader = req.headers.authorization;

    // A protected request must include an Authorization header.
    if (!authHeader) {
        console.log('Authorization header is missing.');
        return res.status(401).json({
            message: 'Authorization is required.'
        });
    }

    // JWT authentication expects the format: "Bearer <token>".
    const authParts = authHeader.split(' ');

    if (authParts.length !== 2 || authParts[0] !== 'Bearer' || !authParts[1]) {
        console.log('Invalid Authorization header format.');
        return res.status(401).json({
            message: 'Invalid authorization format.'
        });
    }

    const token = authParts[1];

    // Verify the token before allowing the request to continue.
    jwt.verify(token, process.env.JWT_SECRET, (err, verified) => {
        if (err) {
            console.log('JWT verification failed.');
            return res.status(401).json({
                message: 'Invalid or expired authentication token.'
            });
        }

        // Store the verified token data for use by later middleware/controllers.
        req.auth = verified;
        next();
    });
}


// Register a new user
router.route('/register')
    .post(authController.register);

// Login an existing user
router.route('/login')
    .post(authController.login);

router.route('/trips')
    .get(tripsController.tripsList)
    .post(authenticateJWT, tripsController.tripsAddTrip);

// GET, UPDATE, or DELETE one trip
router.route('/trips/:tripCode')
    .get(tripsController.tripsFindByCode)
    .put(authenticateJWT, tripsController.tripsUpdateTrip)
    .delete(authenticateJWT, tripsController.tripsDeleteTrip);

module.exports = router;