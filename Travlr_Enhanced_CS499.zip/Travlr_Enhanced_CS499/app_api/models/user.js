const mongoose = require('mongoose');
const crypto = require('crypto');
const jwt = require('jsonwebtoken');

// Password hashing configuration.
// A higher iteration count makes password guessing attacks more expensive
// while retaining the PBKDF2 implementation used by the original application.
const PBKDF2_ITERATIONS = 100000;
const PBKDF2_KEY_LENGTH = 64;
const PBKDF2_DIGEST = 'sha512';

const userSchema = new mongoose.Schema({
    email: {
        type: String,
        unique: true,
        required: true,
        trim: true,
        lowercase: true,
        maxlength: 254
    },
    name: {
        type: String,
        required: true,
        trim: true,
        maxlength: 100
    },
    hash: {
        type: String,
        required: true
    },
    salt: {
        type: String,
        required: true
    }
});

// Hash and store a user's password instead of storing plaintext credentials.
userSchema.methods.setPassword = function (password) {
    // Generate a unique random salt for each user.
    this.salt = crypto.randomBytes(16).toString('hex');

    // PBKDF2 repeatedly hashes the password to make password cracking
    // significantly more computationally expensive.
    this.hash = crypto.pbkdf2Sync(
        password,
        this.salt,
        PBKDF2_ITERATIONS,
        PBKDF2_KEY_LENGTH,
        PBKDF2_DIGEST
    ).toString('hex');
};

// Compare an entered password with the securely stored password hash.
userSchema.methods.validPassword = function (password) {
    // Reject authentication if required credential data is unavailable.
    if (!password || !this.salt || !this.hash) {
        return false;
    }

    const candidateHash = crypto.pbkdf2Sync(
        password,
        this.salt,
        PBKDF2_ITERATIONS,
        PBKDF2_KEY_LENGTH,
        PBKDF2_DIGEST
    );

    const storedHash = Buffer.from(this.hash, 'hex');

    // Ensure both buffers are the same length before using timingSafeEqual.
    // This avoids exposing password comparison timing information.
    if (candidateHash.length !== storedHash.length) {
        return false;
    }

    return crypto.timingSafeEqual(candidateHash, storedHash);
};

// Generate a JSON Web Token after successful authentication.
userSchema.methods.generateJWT = function () {
    // Prevent token generation if the application secret is not configured.
    if (!process.env.JWT_SECRET) {
        throw new Error('JWT_SECRET is not configured.');
    }

    return jwt.sign(
        {
            _id: this._id,
            email: this.email,
            name: this.name
        },
        process.env.JWT_SECRET,
        {
            expiresIn: '1h'
        }
    );
};

const User = mongoose.model('users', userSchema);

module.exports = User;