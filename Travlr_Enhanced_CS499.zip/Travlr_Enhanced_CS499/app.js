const express = require('express');
const path = require('path');
const hbs = require('hbs');
const cors = require('cors');
require('dotenv').config();
const passport = require('passport');
require('./app_api/config/passport');

// Initialize the MongoDB connection when the application starts.
require('./app_api/models/db');

const indexRouter = require('./app_server/routes/index');
const apiRouter = require('./app_api/routes/index');

const app = express();
const PORT = 3000;

// Configure cross-origin requests for the Angular administrative application.
app.use(
    cors({
        origin: 'http://localhost:4200',
        methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
        allowedHeaders: ['Content-Type', 'Authorization']
    })
);

// Parse incoming JSON and URL-encoded request data.
app.use(express.json());
app.use(express.urlencoded({ extended: false }));

// Configure Handlebars for the customer-facing website.
app.set('view engine', 'hbs');
app.set('views', path.join(__dirname, 'app_server', 'views'));

hbs.registerPartials(
    path.join(__dirname, 'app_server', 'views', 'partials')
);

app.use(express.static(path.join(__dirname, 'public')));

// Initialize Passport authentication middleware.
app.use(passport.initialize());

// Route configuration
// All API requests are handled by the API router so protected operations,
// such as creating, updating, or deleting trips, must pass through the
// authentication middleware defined in app_api/routes/index.js.
app.use('/api', apiRouter);

// Customer-facing routes are handled separately from the REST API.
app.use('/', indexRouter);

// Start the Travlr application server.
app.listen(PORT, () => {
    console.log(`Travlr Getaways is running at http://localhost:${PORT}`);
});