import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import {
  FormBuilder,
  FormGroup,
  ReactiveFormsModule,
  Validators
} from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';

import { TripData } from '../services/trip-data';
import { Trip } from '../models/trip';

@Component({
  selector: 'app-edit-trip',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './edit-trip.html',
  styleUrl: './edit-trip.css',
})
export class EditTrip implements OnInit {
  editForm: FormGroup;
  submitted = false;
  message = '';
  originalTripCode = '';

  constructor(
    private formBuilder: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,
    private tripDataService: TripData
  ) {
    this.editForm = this.formBuilder.group({
      code: ['', Validators.required],
      name: ['', Validators.required],
      length: ['', Validators.required],
      start: ['', Validators.required],
      resort: ['', Validators.required],
      perPerson: ['', Validators.required],
      image: ['', Validators.required],
      description: ['', Validators.required]
    });
  }

  ngOnInit(): void {
    this.originalTripCode =
      this.route.snapshot.paramMap.get('tripCode') ?? '';

    if (!this.originalTripCode) {
      this.message = 'No trip code was provided.';
      return;
    }

    this.tripDataService.getTrip(this.originalTripCode).subscribe({
      next: (trip: Trip) => {
        this.editForm.patchValue({
          code: trip.code,
          name: trip.name,
          length: trip.length,
          start: trip.start.substring(0, 10),
          resort: trip.resort,
          perPerson: trip.perPerson,
          image: trip.image,
          description: trip.description
        });
      },
      error: (error: unknown) => {
        console.error('Error retrieving trip:', error);
        this.message = 'Unable to retrieve the trip.';
      }
    });
  }

  get formControls() {
    return this.editForm.controls;
  }

  onSubmit(): void {
    this.submitted = true;

    if (this.editForm.invalid) {
      return;
    }

    const updatedTrip: Trip = this.editForm.value;

    this.tripDataService.updateTrip(updatedTrip).subscribe({
      next: () => {
        this.message = 'Trip updated successfully.';
        this.router.navigate(['/']);
      },
      error: (error: unknown) => {
        console.error('Error updating trip:', error);
        this.message = 'Unable to update the trip.';
      }
    });
  }
}
