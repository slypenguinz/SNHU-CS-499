import {
  ChangeDetectorRef,
  Component,
  OnInit
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';

import { TripCard } from '../trip-card/trip-card';
import { TripData } from '../services/trip-data';
import { Trip } from '../models/trip';
import { Authentication } from '../services/authentication';

@Component({
  selector: 'app-trip-listing',
  standalone: true,
  imports: [
    CommonModule,
    RouterLink,
    TripCard
  ],
  templateUrl: './trip-listing.html',
  styleUrl: './trip-listing.css',
})
export class TripListing implements OnInit {

  trips: Trip[] = [];
  message = '';

  constructor(
    private tripDataService: TripData,
    private authenticationService: Authentication,
    private changeDetectorRef: ChangeDetectorRef
  ) { }

  ngOnInit(): void {
    this.getTrips();
  }

  public isLoggedIn(): boolean {
    return this.authenticationService.isLoggedIn();
  }

  private getTrips(): void {
    this.tripDataService.getTrips().subscribe({
      next: (value: Trip[]) => {
        this.trips = value;

        if (value.length > 0) {
          this.message = `There are ${value.length} trips available.`;
        } else {
          this.message = 'There were no trips retrieved from the database.';
        }

        console.log(this.message);
        this.changeDetectorRef.detectChanges();
      },
      error: (error: unknown) => {
        console.error('Error retrieving trips:', error);
        this.message = 'Unable to retrieve trips from the database.';
        this.changeDetectorRef.detectChanges();
      }
    });
  }

  public deleteTrip(tripCode: string): void {
    const confirmed = window.confirm(
      `Are you sure you want to delete trip ${tripCode}?`
    );

    if (!confirmed) {
      return;
    }

    this.tripDataService.deleteTrip(tripCode).subscribe({
      next: () => {
        this.trips = this.trips.filter(
          (trip) => trip.code !== tripCode
        );

        this.message = 'Trip deleted successfully.';
        this.changeDetectorRef.detectChanges();
      },
      error: (error: unknown) => {
        console.error('Error deleting trip:', error);
        this.message = 'Unable to delete the trip.';
        this.changeDetectorRef.detectChanges();
      }
    });
  }
}
