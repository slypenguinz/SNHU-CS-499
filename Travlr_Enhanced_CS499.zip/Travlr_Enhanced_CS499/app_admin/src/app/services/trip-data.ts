import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

import { Trip } from '../models/trip';
import { User } from '../models/user';
import { AuthResponse } from '../models/auth-response';

@Injectable({
  providedIn: 'root',
})
export class TripData {

  private baseUrl = '/api';

  constructor(private http: HttpClient) { }

  public getTrips(): Observable<Trip[]> {
    return this.http.get<Trip[]>(
      `${this.baseUrl}/trips`
    );
  }

  public getTrip(tripCode: string): Observable<Trip> {
    return this.http.get<Trip>(
      `${this.baseUrl}/trips/${tripCode}`
    );
  }

  public addTrip(formData: Trip): Observable<Trip> {
    return this.http.post<Trip>(
      `${this.baseUrl}/trips`,
      formData
    );
  }

  public updateTrip(formData: Trip): Observable<Trip> {
    return this.http.put<Trip>(
      `${this.baseUrl}/trips/${formData.code}`,
      formData
    );
  }

  public deleteTrip(tripCode: string): Observable<any> {
    return this.http.delete(
      `${this.baseUrl}/trips/${tripCode}`
    );
  }

  public login(
    user: User,
    passwd: string
  ): Observable<AuthResponse> {

    return this.handleAuthAPICall(
      'login',
      user,
      passwd
    );
  }

  public register(
    user: User,
    passwd: string
  ): Observable<AuthResponse> {

    return this.handleAuthAPICall(
      'register',
      user,
      passwd
    );
  }

  private handleAuthAPICall(
    endpoint: string,
    user: User,
    passwd: string
  ): Observable<AuthResponse> {

    const formData = {
      name: user.name,
      email: user.email,
      password: passwd
    };

    return this.http.post<AuthResponse>(
      `${this.baseUrl}/${endpoint}`,
      formData
    );
  }
}
