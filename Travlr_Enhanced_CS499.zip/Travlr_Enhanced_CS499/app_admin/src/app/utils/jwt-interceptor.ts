import { HttpInterceptorFn } from '@angular/common/http';
import { inject } from '@angular/core';

import { Authentication } from '../services/authentication';

export const jwtInterceptor: HttpInterceptorFn = (req, next) => {

  const authenticationService = inject(Authentication);
  const token = authenticationService.getToken();

  // If we have a JWT, add it to the Authorization header
  if (token) {
    const authenticatedRequest = req.clone({
      setHeaders: {
        Authorization: `Bearer ${token}`
      }
    });

    return next(authenticatedRequest);
  }

  // No token available, send the request normally
  return next(req);
};
