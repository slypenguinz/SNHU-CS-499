import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';

import { Authentication } from '../services/authentication';
import { User } from '../models/user';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule
  ],
  templateUrl: './login.html',
  styleUrl: './login.css'
})
export class Login {

  public formError: string = '';
  public submitted = false;

  public credentials = {
    email: '',
    password: ''
  };

  constructor(
    private router: Router,
    private authenticationService: Authentication
  ) { }

  public onLoginSubmit(): void {
    this.submitted = true;
    this.formError = '';

    // Authentication requires only an email address and password.
    if (
      !this.credentials.email.trim() ||
      !this.credentials.password
    ) {
      this.formError = 'Email and password are required.';
      return;
    }

    // Normalize the email before sending credentials to the API.
    const user = {
      email: this.credentials.email.trim().toLowerCase()
    } as User;

    this.authenticationService
      .login(user, this.credentials.password)
      .subscribe({
        next: () => {
          // Return the authenticated administrator to the trip listing.
          this.router.navigate(['']);
        },
        error: () => {
          // Display a generic message without revealing account details.
          this.formError =
            'Login failed. Please check your email and password.';
        }
      });
  }
}
