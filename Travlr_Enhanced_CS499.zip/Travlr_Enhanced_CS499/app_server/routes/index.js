const express = require('express');
const router = express.Router();

const ctrlTravlr = require('../controllers/travlr');
const ctrlTravel = require('../controllers/travel');

/* GET home page */
router.get('/', ctrlTravlr.index);

/* GET travel page */
router.get('/travel', ctrlTravel.travel);

module.exports = router;