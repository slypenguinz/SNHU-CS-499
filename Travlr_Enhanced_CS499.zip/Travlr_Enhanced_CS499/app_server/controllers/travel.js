const mongoose = require('mongoose');

// Load the Trip model from the API models folder
require('../../app_api/models/travlr');

const Trip = mongoose.model('trips');

/* GET travel view */
const travel = async (req, res) => {
    try {
        const trips = await Trip
            .find({})
            .exec();

        res.render('travel', {
            title: 'Travlr Getaways',
            trips
        });
    } catch (err) {
        console.error('Error retrieving trips:', err);

        res.status(500).render('travel', {
            title: 'Travlr Getaways',
            trips: [],
            message: 'Unable to retrieve trips.'
        });
    }
};

module.exports = {
    travel
};